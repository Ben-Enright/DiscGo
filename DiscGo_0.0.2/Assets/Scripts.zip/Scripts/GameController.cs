﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameController : MonoBehaviour {

	public GameObject disc;
	public GameObject bg;
	public GameObject ball;

	private Renderer discRenderer;
	private Renderer bgRenderer;
	private Renderer ballRenderer;

	private int discColor;
	private int bgColor;
	private int ballColor;

   // public GameObject disc1;
    public GameObject disc2;
    public GameObject disc3;
    public GameObject disc4;
    public GameObject disc5;
    public GameObject disc6;
    public GameObject disc7;
    public GameObject disc8;
    public GameObject disc9;
    public GameObject disc10;
    public GameObject disc11;
    public GameObject disc12;
    public GameObject disc13;
    public GameObject disc14;
	public GameObject heart;
	public GameObject points;
	public GameObject ball1;
	public GameObject bg1;
	public GameObject menuDisc;
	public GameObject menuBG;


	public GameObject menuHeart;
	public GameObject menuHeart1;
	public GameObject menuStar;
	public GameObject menuStar1;
	public GameObject music;
	public GameObject introMusic;

	public Text menu;
	public Text menu1;
	public Text instructions;
	public Text instructions1;
	public Text thankyou;

	public Camera gameCamera;
	public Camera menuCamera;
	public Camera gameOverCamera;

    public Vector3 spawnValues;

    private int rand;
	private int randPU;
	private float rotation;
	private float border;
	private float spacing;

    void Start () {

		ballRenderer = ball.GetComponent<Renderer>();
		bgRenderer = bg.GetComponent<Renderer>();
		discRenderer = disc.GetComponent<Renderer>();


		gameCamera.enabled = false;
		menuCamera.enabled = true;
		gameOverCamera.enabled = false;
		music.gameObject.SetActive (false);
		border = 0.75f;
		ball1.gameObject.SetActive (false);
		bg1.gameObject.SetActive (false);
		menuHeart.gameObject.SetActive (false);
		menuHeart1.gameObject.SetActive (false);
		menuStar.gameObject.SetActive (false);
		menuStar1.gameObject.SetActive (false);
		menu.text = "DiscGO";
		menu1.text = "Press 'I' to Start";
		thankyou.text = "Credit & special thanks to Com Truise for the music!";
		instructions.text = "";
		instructions1.text = "";
	}
	

	void Update () {
	
        if (Input.GetKeyDown(KeyCode.R))
        {
            Application.LoadLevel(Application.loadedLevel);
        }

		if (Input.GetKeyDown (KeyCode.I)) {
			Instructions ();	
		}

		if (Input.GetKeyDown (KeyCode.P)) {
			StartGame ();
		}

		if (Input.GetKeyDown(KeyCode.Q)) {
			Application.Quit();
		}

	}

	void Instructions ()
	{
		menu.text = "";
		menu1.text = "";
		menuHeart.gameObject.SetActive (true);
		menuHeart1.gameObject.SetActive (true);
		menuStar.gameObject.SetActive (true);
		menuStar1.gameObject.SetActive (true);
		instructions.text = "Go through each disc\nAvoid being hit\nCollect hearts for lives\nCollect stars for additional points";
		instructions1.text = "Press P to Start the Game!";
	}

	void StartGame ()
	{
		instructions.text = "";
		instructions1.text = "";
		thankyou.text = "";
		menuCamera.enabled = false;
		gameCamera.enabled = true;

		menuHeart.gameObject.SetActive (false);
		menuHeart1.gameObject.SetActive (false);
		menuStar.gameObject.SetActive (false);
		menuStar1.gameObject.SetActive (false);
		menuDisc.gameObject.SetActive (false);
		menuBG.gameObject.SetActive (false);
		introMusic.gameObject.SetActive (false);

		music.gameObject.SetActive (true);
		ball1.gameObject.SetActive (true);
		bg1.gameObject.SetActive (true);
		Enumerators ();
	}

	void Enumerators ()
	{
		StartCoroutine(SpawnWaves());
		StartCoroutine (SpawnPU ());
		StartCoroutine (SpawnPoints ());
		StartCoroutine(IntroColorSwitcher());
	}



    IEnumerator SpawnWaves ()
    {
        while (true)
        {
			yield return new WaitForSeconds(2);
            Vector3 spawnPosition = new Vector3(spawnValues.x, spawnValues.y, spawnValues.z);
            Quaternion spawnRotation = Quaternion.identity;
            int rand = Random.Range(2, 14);

            if (rand == 2)
            {
                Instantiate(disc2, spawnPosition, spawnRotation);               
            }

            else if (rand == 3)
            {
                Instantiate(disc3, spawnPosition, spawnRotation);               
            }

            else if (rand == 4)
            {
                Instantiate(disc4, spawnPosition, spawnRotation);               
            }

            else if (rand == 5)
            {
                Instantiate(disc5, spawnPosition, spawnRotation);                
            }

            else if (rand == 6)
            {
                Instantiate(disc6, spawnPosition, spawnRotation);                
            }

            else if (rand == 7)
            {
                Instantiate(disc7, spawnPosition, spawnRotation);               
            }

            else if (rand == 8)
            {
                Instantiate(disc8, spawnPosition, spawnRotation);               
            }

            else if (rand == 9)
            {
                Instantiate(disc9, spawnPosition, spawnRotation);
            }

            else if (rand == 10)
            {
                Instantiate(disc10, spawnPosition, spawnRotation);           
            }

            else if (rand == 11)
            {
                Instantiate(disc11, spawnPosition, spawnRotation);              
            }

            else if (rand == 12)
            {
                Instantiate(disc12, spawnPosition, spawnRotation);               
            }

            else if (rand == 13)
            {
                Instantiate(disc13, spawnPosition, spawnRotation);              
            }

            else if (rand == 14)
            {
                Instantiate(disc14, spawnPosition, spawnRotation);               
            }
        }
    }

	IEnumerator SpawnPoints ()
	{
		while (true) 
		{
			spacing = Random.Range (0.4f, 0.6f);
			yield return new WaitForSeconds (4.0f + spacing);
			Vector3 spawnPointPosition = new Vector3(Random.Range(-border,border), Random.Range(-border,border), 0.0f);
			Quaternion spawnPointRotation = Quaternion.identity;
			Instantiate (points, spawnPointPosition, spawnPointRotation);
		}
	}

	IEnumerator SpawnPU ()
	{
		while (true) {
			yield return new WaitForSeconds (14.0f + spacing);
			Vector3 spawnPUPosition = new Vector3 (Random.Range (-border, border), Random.Range (-border, border), 0.0f);
			Quaternion spawnPURotation = Quaternion.identity;
			int randPU = Random.Range (1, 3);

			if (randPU == 1) {
				Instantiate (heart, spawnPUPosition, spawnPURotation);
			}
		}
	}


	IEnumerator ColorSwitcher() {

		yield return new WaitForSeconds(1);

		discColor = Random.Range(1, 21);
		bgColor = Random.Range(1, 21);
		ballColor = Random.Range (1, 21);


		//Change Disc Color
		if (discColor == 1)
		{
			discRenderer.sharedMaterial.color = Color.red;
		}
		else if (discColor == 2)
		{
			discRenderer.sharedMaterial.color = Color.yellow;
		}
		else if (discColor == 3)
		{
			discRenderer.sharedMaterial.color = Color.blue;
		}
		else if (discColor == 4)
		{
			discRenderer.sharedMaterial.color = Color.green;
		}
		else if (discColor == 5)
		{
			discRenderer.sharedMaterial.color = Color.magenta;
		}
		else if (discColor == 6)
		{
			discRenderer.sharedMaterial.color = Color.cyan;
		}
		else if (discColor == 7)
		{
			discRenderer.sharedMaterial.color = Color.white;
		}
		else if (discColor == 8)
		{
			discRenderer.sharedMaterial.color = Color.black;
		}
		else if (discColor == 9)
		{
			discRenderer.sharedMaterial.color = Color.yellow + Color.red;
		}
		else if (discColor == 10)
		{
			discRenderer.sharedMaterial.color = Color.green + Color.yellow;
		}
		else if (discColor == 11)
		{
			discRenderer.sharedMaterial.color = Color.green + Color.blue;
		}
		else if (discColor == 12)
		{
			discRenderer.sharedMaterial.color = Color.blue + Color.red;
		}
		else if (discColor == 13)
		{
			discRenderer.sharedMaterial.color = Color.blue + Color.magenta;
		}
		else if (discColor == 14)
		{
			discRenderer.sharedMaterial.color = Color.red + Color.magenta;
		}
		else if (discColor == 15)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.blue;
		}
		else if (discColor == 16)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.red;
		}
		else if (discColor == 17)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.green;
		}
		else if (discColor == 18)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.yellow;
		}
		else if (discColor == 19)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.cyan;
		}
		else if (discColor == 20)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.magenta;
		}


		//Change BG Color
		if (bgColor == 1)
		{
			bgRenderer.material.color = Color.red;
		}
		else if (bgColor == 2)
		{
			bgRenderer.material.color = Color.yellow;
		}
		else if (bgColor == 3)
		{
			bgRenderer.material.color = Color.blue;
		}
		else if (bgColor == 4)
		{
			bgRenderer.material.color = Color.green;
		}
		else if (bgColor == 5)
		{
			bgRenderer.material.color = Color.magenta;
		}
		else if (bgColor == 6)
		{
			bgRenderer.material.color = Color.cyan;
		}
		else if (bgColor == 7)
		{
			bgRenderer.material.color = Color.white;
		}
		else if (bgColor == 8)
		{
			bgRenderer.material.color = Color.black;
		}
		else if (bgColor == 9)
		{
			bgRenderer.material.color = Color.yellow + Color.red;
		}
		else if (bgColor == 10)
		{
			bgRenderer.material.color = Color.green + Color.yellow;
		}
		else if (bgColor == 11)
		{
			bgRenderer.material.color = Color.green + Color.blue;
		}
		else if (bgColor == 12)
		{
			bgRenderer.material.color = Color.blue + Color.red;
		}
		else if (bgColor == 13)
		{
			bgRenderer.material.color = Color.blue + Color.magenta;
		}
		else if (bgColor == 14)
		{
			bgRenderer.material.color = Color.red + Color.magenta;
		}
		else if (bgColor == 15)
		{
			bgRenderer.material.color = Color.white + Color.blue;
		}
		else if (bgColor == 16)
		{
			bgRenderer.material.color = Color.white + Color.red;
		}
		else if (bgColor == 17)
		{
			bgRenderer.material.color = Color.white + Color.green;
		}
		else if (bgColor == 18)
		{
			bgRenderer.material.color = Color.white + Color.yellow;
		}
		else if (bgColor == 19)
		{
			bgRenderer.material.color = Color.white + Color.cyan;
		}
		else if (bgColor == 20)
		{
			bgRenderer.material.color = Color.white + Color.magenta;
		}


		//Change Ball Color
		if (ballColor == 1)
		{
			ballRenderer.material.color = Color.red;
		}
		else if (ballColor == 2)
		{
			ballRenderer.material.color = Color.yellow;
		}
		else if (ballColor == 3)
		{
			ballRenderer.material.color = Color.blue;
		}
		else if (ballColor == 4)
		{
			ballRenderer.material.color = Color.green;
		}
		else if (ballColor == 5)
		{
			ballRenderer.material.color = Color.magenta;
		}
		else if (ballColor == 6)
		{
			ballRenderer.material.color = Color.cyan;
		}
		else if (ballColor == 7)
		{
			ballRenderer.material.color = Color.white;
		}
		else if (ballColor == 8)
		{
			ballRenderer.material.color = Color.black;
		}
		else if (ballColor == 9)
		{
			ballRenderer.material.color = Color.yellow + Color.red;
		}
		else if (ballColor == 10)
		{
			ballRenderer.material.color = Color.green + Color.yellow;
		}
		else if (ballColor == 11)
		{
			ballRenderer.material.color = Color.green + Color.blue;
		}
		else if (ballColor == 12)
		{
			ballRenderer.material.color = Color.blue + Color.red;
		}
		else if (ballColor == 13)
		{
			ballRenderer.material.color = Color.blue + Color.magenta;
		}
		else if (ballColor == 14)
		{
			ballRenderer.material.color = Color.red + Color.magenta;
		}
		else if (ballColor == 15)
		{
			ballRenderer.material.color = Color.white + Color.blue;
		}
		else if (ballColor == 16)
		{
			ballRenderer.material.color = Color.white + Color.red;
		}
		else if (ballColor == 17)
		{
			ballRenderer.material.color = Color.white + Color.green;
		}
		else if (ballColor == 18)
		{
			ballRenderer.material.color = Color.white + Color.yellow;
		}
		else if (ballColor == 19)
		{
			ballRenderer.material.color = Color.white + Color.cyan;
		}
		else if (ballColor == 20)
		{
			ballRenderer.material.color = Color.white + Color.magenta;
		}

		StartCoroutine(ColorSwitcher());

	}

	IEnumerator IntroColorSwitcher() {

		yield return new WaitForSeconds(2);

		for (int i = 0; i < 20; i++)
		{
			discColor = Random.Range(1, 21);
			bgColor = Random.Range(1, 21);
			ballColor = Random.Range (1, 21);


			//Change Disc Color
			if (discColor == 1)
			{
				discRenderer.sharedMaterial.color = Color.red;
			}
			else if (discColor == 2)
			{
				discRenderer.sharedMaterial.color = Color.yellow;
			}
			else if (discColor == 3)
			{
				discRenderer.sharedMaterial.color = Color.blue;
			}
			else if (discColor == 4)
			{
				discRenderer.sharedMaterial.color = Color.green;
			}
			else if (discColor == 5)
			{
				discRenderer.sharedMaterial.color = Color.magenta;
			}
			else if (discColor == 6)
			{
				discRenderer.sharedMaterial.color = Color.cyan;
			}
			else if (discColor == 7)
			{
				discRenderer.sharedMaterial.color = Color.white;
			}
			else if (discColor == 8)
			{
				discRenderer.sharedMaterial.color = Color.black;
			}
			else if (discColor == 9)
			{
				discRenderer.sharedMaterial.color = Color.yellow + Color.red;
			}
			else if (discColor == 10)
			{
				discRenderer.sharedMaterial.color = Color.green + Color.yellow;
			}
			else if (discColor == 11)
			{
				discRenderer.sharedMaterial.color = Color.green + Color.blue;
			}
			else if (discColor == 12)
			{
				discRenderer.sharedMaterial.color = Color.blue + Color.red;
			}
			else if (discColor == 13)
			{
				discRenderer.sharedMaterial.color = Color.blue + Color.magenta;
			}
			else if (discColor == 14)
			{
				discRenderer.sharedMaterial.color = Color.red + Color.magenta;
			}
			else if (discColor == 15)
			{
				discRenderer.sharedMaterial.color = Color.white + Color.blue;
			}
			else if (discColor == 16)
			{
				discRenderer.sharedMaterial.color = Color.white + Color.red;
			}
			else if (discColor == 17)
			{
				discRenderer.sharedMaterial.color = Color.white + Color.green;
			}
			else if (discColor == 18)
			{
				discRenderer.sharedMaterial.color = Color.white + Color.yellow;
			}
			else if (discColor == 19)
			{
				discRenderer.sharedMaterial.color = Color.white + Color.cyan;
			}
			else if (discColor == 20)
			{
				discRenderer.sharedMaterial.color = Color.white + Color.magenta;
			}


			//Change BG Color
			if (bgColor == 1)
			{
				bgRenderer.material.color = Color.red;
			}
			else if (bgColor == 2)
			{
				bgRenderer.material.color = Color.yellow;
			}
			else if (bgColor == 3)
			{
				bgRenderer.material.color = Color.blue;
			}
			else if (bgColor == 4)
			{
				bgRenderer.material.color = Color.green;
			}
			else if (bgColor == 5)
			{
				bgRenderer.material.color = Color.magenta;
			}
			else if (bgColor == 6)
			{
				bgRenderer.material.color = Color.cyan;
			}
			else if (bgColor == 7)
			{
				bgRenderer.material.color = Color.white;
			}
			else if (bgColor == 8)
			{
				bgRenderer.material.color = Color.black;
			}
			else if (bgColor == 9)
			{
				bgRenderer.material.color = Color.yellow + Color.red;
			}
			else if (bgColor == 10)
			{
				bgRenderer.material.color = Color.green + Color.yellow;
			}
			else if (bgColor == 11)
			{
				bgRenderer.material.color = Color.green + Color.blue;
			}
			else if (bgColor == 12)
			{
				bgRenderer.material.color = Color.blue + Color.red;
			}
			else if (bgColor == 13)
			{
				bgRenderer.material.color = Color.blue + Color.magenta;
			}
			else if (bgColor == 14)
			{
				bgRenderer.material.color = Color.red + Color.magenta;
			}
			else if (bgColor == 15)
			{
				bgRenderer.material.color = Color.white + Color.blue;
			}
			else if (bgColor == 16)
			{
				bgRenderer.material.color = Color.white + Color.red;
			}
			else if (bgColor == 17)
			{
				bgRenderer.material.color = Color.white + Color.green;
			}
			else if (bgColor == 18)
			{
				bgRenderer.material.color = Color.white + Color.yellow;
			}
			else if (bgColor == 19)
			{
				bgRenderer.material.color = Color.white + Color.cyan;
			}
			else if (bgColor == 20)
			{
				bgRenderer.material.color = Color.white + Color.magenta;
			}


			//Change Ball Color
			if (ballColor == 1)
			{
				ballRenderer.material.color = Color.red;
			}
			else if (ballColor == 2)
			{
				ballRenderer.material.color = Color.yellow;
			}
			else if (ballColor == 3)
			{
				ballRenderer.material.color = Color.blue;
			}
			else if (ballColor == 4)
			{
				ballRenderer.material.color = Color.green;
			}
			else if (ballColor == 5)
			{
				ballRenderer.material.color = Color.magenta;
			}
			else if (ballColor == 6)
			{
				ballRenderer.material.color = Color.cyan;
			}
			else if (ballColor == 7)
			{
				ballRenderer.material.color = Color.white;
			}
			else if (ballColor == 8)
			{
				ballRenderer.material.color = Color.black;
			}
			else if (ballColor == 9)
			{
				ballRenderer.material.color = Color.yellow + Color.red;
			}
			else if (ballColor == 10)
			{
				ballRenderer.material.color = Color.green + Color.yellow;
			}
			else if (ballColor == 11)
			{
				ballRenderer.material.color = Color.green + Color.blue;
			}
			else if (ballColor == 12)
			{
				ballRenderer.material.color = Color.blue + Color.red;
			}
			else if (ballColor == 13)
			{
				ballRenderer.material.color = Color.blue + Color.magenta;
			}
			else if (ballColor == 14)
			{
				ballRenderer.material.color = Color.red + Color.magenta;
			}
			else if (ballColor == 15)
			{
				ballRenderer.material.color = Color.white + Color.blue;
			}
			else if (ballColor == 16)
			{
				ballRenderer.material.color = Color.white + Color.red;
			}
			else if (ballColor == 17)
			{
				ballRenderer.material.color = Color.white + Color.green;
			}
			else if (ballColor == 18)
			{
				ballRenderer.material.color = Color.white + Color.yellow;
			}
			else if (ballColor == 19)
			{
				ballRenderer.material.color = Color.white + Color.cyan;
			}
			else if (ballColor == 20)
			{
				ballRenderer.material.color = Color.white + Color.magenta;
			}

			yield return new WaitForSeconds (0.25f);

		}

		yield return new WaitForSeconds (0.3f);
		StartCoroutine(ColorSwitcher());
	}
}