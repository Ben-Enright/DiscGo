﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Colors : MonoBehaviour {

    public GameObject disc;
    public GameObject bg;

	private Renderer discRenderer;
	private Renderer bgRenderer;

	private int discColor;
	private int bgColor;


    void Start() {

        bgRenderer = bg.GetComponent<Renderer>();
        discRenderer = disc.GetComponent<Renderer>();

        StartCoroutine(ColorSwitcher());

    }

    IEnumerator ColorSwitcher() {

		discColor = Random.Range(1, 21);
        bgColor = Random.Range(1, 21);


		//Change Disc Color
		if (discColor == 1)
		{
			discRenderer.sharedMaterial.color = Color.red;
		}
		else if (discColor == 2)
		{
			discRenderer.sharedMaterial.color = Color.yellow;
		}
		else if (discColor == 3)
		{
			discRenderer.sharedMaterial.color = Color.blue;
		}
		else if (discColor == 4)
		{
			discRenderer.sharedMaterial.color = Color.green;
		}
		else if (discColor == 5)
		{
			discRenderer.sharedMaterial.color = Color.magenta;
		}
		else if (discColor == 6)
		{
			discRenderer.sharedMaterial.color = Color.cyan;
		}
		else if (discColor == 7)
		{
			discRenderer.sharedMaterial.color = Color.white;
		}
		else if (discColor == 8)
		{
			discRenderer.sharedMaterial.color = Color.black;
		}
		else if (discColor == 9)
		{
			discRenderer.sharedMaterial.color = Color.yellow + Color.red;
		}
		else if (discColor == 10)
		{
			discRenderer.sharedMaterial.color = Color.green + Color.yellow;
		}
		else if (discColor == 11)
		{
			discRenderer.sharedMaterial.color = Color.green + Color.blue;
		}
		else if (discColor == 12)
		{
			discRenderer.sharedMaterial.color = Color.blue + Color.red;
		}
		else if (discColor == 13)
		{
			discRenderer.sharedMaterial.color = Color.blue + Color.magenta;
		}
		else if (discColor == 14)
		{
			discRenderer.sharedMaterial.color = Color.red + Color.magenta;
		}
		else if (discColor == 15)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.blue;
		}
		else if (discColor == 16)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.red;
		}
		else if (discColor == 17)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.green;
		}
		else if (discColor == 18)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.yellow;
		}
		else if (discColor == 19)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.cyan;
		}
		else if (discColor == 20)
		{
			discRenderer.sharedMaterial.color = Color.white + Color.magenta;
		}


		//Change BG Color
		if (bgColor == 1)
		{
			bgRenderer.material.color = Color.red;
		}
		else if (bgColor == 2)
		{
			bgRenderer.material.color = Color.yellow;
		}
		else if (bgColor == 3)
		{
			bgRenderer.material.color = Color.blue;
		}
		else if (bgColor == 4)
		{
			bgRenderer.material.color = Color.green;
		}
		else if (bgColor == 5)
		{
			bgRenderer.material.color = Color.magenta;
		}
		else if (bgColor == 6)
		{
			bgRenderer.material.color = Color.cyan;
		}
		else if (bgColor == 7)
		{
			bgRenderer.material.color = Color.white;
		}
		else if (bgColor == 8)
		{
			bgRenderer.material.color = Color.black;
		}
		else if (bgColor == 9)
		{
			bgRenderer.material.color = Color.yellow + Color.red;
		}
		else if (bgColor == 10)
		{
			bgRenderer.material.color = Color.green + Color.yellow;
		}
		else if (bgColor == 11)
		{
			bgRenderer.material.color = Color.green + Color.blue;
		}
		else if (bgColor == 12)
		{
			bgRenderer.material.color = Color.blue + Color.red;
		}
		else if (bgColor == 13)
		{
			bgRenderer.material.color = Color.blue + Color.magenta;
		}
		else if (bgColor == 14)
		{
			bgRenderer.material.color = Color.red + Color.magenta;
		}
		else if (bgColor == 15)
		{
			bgRenderer.material.color = Color.white + Color.blue;
		}
		else if (bgColor == 16)
		{
			bgRenderer.material.color = Color.white + Color.red;
		}
		else if (bgColor == 17)
		{
			bgRenderer.material.color = Color.white + Color.green;
		}
		else if (bgColor == 18)
		{
			bgRenderer.material.color = Color.white + Color.yellow;
		}
		else if (bgColor == 19)
		{
			bgRenderer.material.color = Color.white + Color.cyan;
		}
		else if (bgColor == 20)
		{
			bgRenderer.material.color = Color.white + Color.magenta;
		}

		yield return new WaitForSeconds (0.5f);

        StartCoroutine(ColorSwitcher());

    }
}
