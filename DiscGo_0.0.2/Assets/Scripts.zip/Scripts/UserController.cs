﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

[System.Serializable]
public class Boundary
{
    public float xMin, xMax, yMin, yMax;
}



public class UserController : MonoBehaviour
{

	public Text gameOverText;
    public Text restartText;
    public Text safeguardText;
	public float speed;
    public Boundary boundary;


	public Text scoreText;
	public Text livesText;
	public Text scoreText1;
	public Text livesText1;

	public Camera gameCamera;
	public Camera menuCamera;
	public Camera gameOverCamera;
	public GameObject pointsSound;
	public GameObject lifeSound;
	public GameObject errorSound;

	private float lives;
	private float score;
    private float safeguard;
	private Rigidbody rb;
	private AudioSource audio;

    void Start()
    {
		gameCamera.enabled = true;
		menuCamera.enabled = false;
		pointsSound.gameObject.SetActive (false);
		lifeSound.gameObject.SetActive (false);
		errorSound.gameObject.SetActive (false);
		rb = GetComponent<Rigidbody>();
		audio = GetComponent<AudioSource>();
        safeguard = 0;
        gameOverText.text = "";
        restartText.text = "";
		scoreText.text = "";
		livesText.text = "";
		scoreText1.text = "";
		livesText1.text = "";

		score = 0;
		lives = 1;
    }


    void Update()
    {

        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(-moveHorizontal, moveVertical, 0.0f);
		rb.velocity = movement * speed;


        //SafeguardText();

        rb.position = new Vector3
        (
            Mathf.Clamp(rb.position.x, boundary.xMin, boundary.xMax),
            Mathf.Clamp(rb.position.y, boundary.yMin, boundary.yMax),
            16.83f
        );

    }

	void SetScoreText ()
	{
		scoreText.text = "Score: " + score.ToString();
		scoreText1.text = "Score: " + score.ToString();
	}

	void SetLivesText ()
	{
		livesText.text = "Lives: " + lives.ToString();
		livesText1.text = "Lives: " + lives.ToString();
	}


    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Win_Boundary"))
        {
			audio.Play ();
            score = score + 10;
            safeguard = safeguard + 1;
			SetScoreText();
			SetLivesText();

        }

        if (other.gameObject.CompareTag("Lose_Boundary"))
        {

            if (safeguard > 0)
            {
                safeguard = safeguard - 1;
            }

            else if (safeguard == 0)
            {
				StartCoroutine (ErrorFX ());
                if (lives > 0)
                {
                    lives = lives - 1;
                    score = score - 100;
					SetLivesText();
					SetScoreText();
                }

                else if (lives == 0)
                {
					gameObject.SetActive(false); 
					gameCamera.enabled = false;
					menuCamera.enabled = true;
                    GameOver();
                }
            }
        }

        if (other.gameObject.CompareTag("LifePU"))
        {
			Destroy (other.gameObject);
			StartCoroutine (LifeFX ());
            lives = lives + 1;
			SetLivesText();
        }

		if (other.gameObject.CompareTag("Points"))
		{
			Destroy (other.gameObject);
			StartCoroutine (PointsFX ());
			score = score + 15;
			SetScoreText();
		}
        
    }
   

    void SafeguardText()
    {
        safeguardText.text = "Safeguard: " + safeguard.ToString();
    }

    public void GameOver()
    {
        gameOverText.text = "Game Over!";
        restartText.text = "Press 'R' for Restart       Press 'Q' to Quit";
		gameCamera.enabled = false;
		gameOverCamera.enabled = true;
    }

	IEnumerator PointsFX ()
	{
		pointsSound.gameObject.SetActive (true);
		yield return new WaitForSeconds (2);
		pointsSound.gameObject.SetActive (false);
	}

	IEnumerator LifeFX ()
	{
		lifeSound.gameObject.SetActive (true);
		yield return new WaitForSeconds (5);
		lifeSound.gameObject.SetActive (false);
	}

	IEnumerator ErrorFX ()
	{
		errorSound.gameObject.SetActive (true);
		yield return new WaitForSeconds (1.5f);
		errorSound.gameObject.SetActive (false);
	}
}
